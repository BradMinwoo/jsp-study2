package study;

public class Main {
	public static void main(String[] args) {
			//		Runnable  a = null;
		   // interface가 하나 이기 때문에 가능
		Lambda lamb = () -> {System.out.println("달립니다.");};
		lamb.run();	
	
	}
	
}
