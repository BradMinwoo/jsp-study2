package study;

public interface Lambda {
	public void run();
	
}

//Lambda로 만들수 있는 interface는 메소드가 1개인 interface만 가능