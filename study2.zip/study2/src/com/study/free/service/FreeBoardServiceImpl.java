package com.study.free.service;

import java.util.List;

import com.study.exception.BizNotEffectedException;
import com.study.exception.BizNotFoundException;
import com.study.exception.BizPasswordNotMatchedException;
import com.study.free.dao.FreeBoardDaoOracle;
import com.study.free.dao.IFreeBoardDao;
import com.study.free.vo.FreeBoardVO;

public class FreeBoardServiceImpl implements IFreeBoardService{

	IFreeBoardDao freeBoardDao = new FreeBoardDaoOracle();
	
	@Override
	public List<FreeBoardVO> getBoardList() {
		List<FreeBoardVO> freeBoardList = freeBoardDao.getBoardList();
		return freeBoardList;
	}

	@Override
	public FreeBoardVO getBoard(int boNo) throws BizNotFoundException {
		FreeBoardVO freeBoard=freeBoardDao.getBoard(boNo);
		if(freeBoard == null) throw new BizNotFoundException();
		// 던지면 던진곳에서 처리 뷰에서처리
		return freeBoard;
	}

	@Override
	public void increaseHit(int boNo) throws BizNotEffectedException {
		int cnt =freeBoardDao.increaseHit(boNo);
		if(cnt == 0 ) throw new BizNotEffectedException();
	}

	@Override
	public void modifyBoard(FreeBoardVO freeBoard)
			throws BizNotFoundException, BizPasswordNotMatchedException, BizNotEffectedException {
		// 사용자가 글 등록했을 때의 비밀번호랑 지금 수정하려는 사람이 입력한 비밀번호라 
		// 같으면 ... 같은 사람이구나 인식해서 그 때만 수정
		FreeBoardVO vo = freeBoardDao.getBoard(freeBoard.getBoNo());
		// 글 등록 했을 때의 비밀번호를            가지고 있는 객체 getBoard 디비에서 가져온것을 vo에 저장
		// 지금 수정하려는 사람이 입력한 비밀번호를 가지고 있는 객체
		// vo, freeBoard
		if(vo==null) throw new BizNotFoundException();
		if(vo.getBoPass().equals(freeBoard.getBoPass())) throw new BizPasswordNotMatchedException();
		int resultCnt = freeBoardDao.updateBoard(freeBoard);
		if(resultCnt == 0) throw new BizNotEffectedException(); // 없데이트가 안되면
	}

	@Override
	public void removeBoard(FreeBoardVO freeBoard)
			throws BizNotFoundException, BizPasswordNotMatchedException, BizNotEffectedException {
		// 사용자가 글 등록했을 때의 비밀번호랑 지금 수정하려는 사람이 입력한 비밀번호라 
		// 같으면 ... 같은 사람이구나 인식해서 그 때만 수정
		FreeBoardVO vo = freeBoardDao.getBoard(freeBoard.getBoNo());
		// 글 등록 했을 때의 비밀번호를            가지고 있는 객체 getBoard 디비에서 가져온것을 vo에 저장
		// 지금 수정하려는 사람이 입력한 비밀번호를 가지고 있는 객체
		// vo, freeBoard
		if(vo==null) throw new BizNotFoundException();
		if(vo.getBoPass().equals(freeBoard.getBoPass())) throw new BizPasswordNotMatchedException();
		int resultCnt = freeBoardDao.updateBoard(freeBoard);
		if(resultCnt == 0) throw new BizNotEffectedException(); // 없데이트가 안되면
			
	}

	@Override
	public void registBoard(FreeBoardVO freeBoard) throws BizNotEffectedException {
		int resultCnt = freeBoardDao.insertBoard(freeBoard);
	}

	//IFreeBoardService, FreeBoardServiceImpl
}
