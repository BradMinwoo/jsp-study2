package com.study.member.service;

import java.util.List;

import com.study.exception.BizDuplicateKeyException;
import com.study.exception.BizNotEffectedException;
import com.study.exception.BizNotFoundException;
import com.study.exception.BizPasswordNotMatchedException;
import com.study.free.vo.FreeBoardVO;
import com.study.member.dao.IMemberDao;
import com.study.member.dao.MemberDaoOracle;
import com.study.member.vo.MemberVO;

public class MemberServiceImpl implements IMemberService {

	IMemberDao memberDao = new MemberDaoOracle();
	
	@Override
	public List<MemberVO> getMemberList() {
		List<MemberVO> memberList = memberDao.getMemberList();
		return memberList;
	}

	@Override
	public MemberVO getMember(String memId) throws BizNotFoundException {
		MemberVO member = memberDao.getMember(memId);
		if(member == null)throw new BizNotFoundException();
		return member;
	}

	@Override
	public void modifyMember(MemberVO member) throws BizNotEffectedException, BizNotFoundException {
		MemberVO vo = memberDao.getMember(member.getMemId());
		if(vo==null) throw new BizNotFoundException();
		int resultCnt = memberDao.updateMember(member);
		if(resultCnt == 0) throw new BizNotEffectedException(); // 없데이트가 안되면

	}

	@Override
	public void removeMember(MemberVO member) throws BizNotEffectedException, BizNotFoundException {
		MemberVO vo = memberDao.getMember(member.getMemId());
		if(vo==null) throw new BizNotFoundException();
		int resultCnt = memberDao.deleteMember(member);
		if(resultCnt == 0) throw new BizNotEffectedException(); // 없데이트가 안되면
		
	}

	@Override
	public void registMember(MemberVO member) throws BizNotEffectedException, BizDuplicateKeyException {
		// 파라미터로 받은 MemberVO 객체
		// DB에 저장되어있는 MemberVIO 객체
		
		MemberVO vo = memberDao.getMember(member.getMemId());
		if(vo != null)  throw new BizDuplicateKeyException();
		else if(vo ==null) {
			int resultCnt = memberDao.insertMember(member);
			if(resultCnt==0) throw new BizNotEffectedException();
		}

	}

}
