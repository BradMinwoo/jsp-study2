

public class ServiceImpl {
	private static ServiceImpl serviceImpl = new ServiceImpl();
	
	private ServiceImpl() {
		
	}
	public static ServiceImpl getInstance() {
		return serviceImpl;
	}
	public void getBoardList() {
		System.out.println("보드에서 데이터 가져왔습니다.");
	}
	
}
