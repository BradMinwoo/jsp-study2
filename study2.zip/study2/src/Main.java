import service.ServiceImpl;

public class Main {

	public static void main(String[] args) {
		//singleTon 만드는 방법 순서1
		// 1. 생성자 private   ===> new 못함
		// 2. 필드에 private  변수
		// 3. static 메소드 getInstance()
		ServiceImpl service1 = ServiceImpl.getInstance();
		ServiceImpl service2 =  ServiceImpl.getInstance();
		
		service1.getBoardList();
		service2.getBoardList();
		
	}

}
