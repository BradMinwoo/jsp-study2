package com.study.member.service;

import java.util.List;

import com.study.exception.BizDuplicateKeyException;
import com.study.exception.BizNotEffectedException;
import com.study.exception.BizNotFoundException;
import com.study.member.dao.IMemberDao;
import com.study.member.dao.MemberDaoOracle;
import com.study.member.vo.MemberSearchVO;
import com.study.member.vo.MemberVO;

public class MemberServiceImpl implements IMemberService{
	IMemberDao memberDao = new MemberDaoOracle();

	// 리스트
	@Override
	public List<MemberVO> getMemberList(MemberSearchVO searchVO) {
		int totalRowCount = memberDao.getTotalRowCount(searchVO);
		searchVO.setTotalRowCount(totalRowCount);
		searchVO.pageSetting();
		List<MemberVO> memberList = memberDao.getMemberList(searchVO);
		return memberList;
	}

	// 뷰
	@Override
	public MemberVO getMember(String memId) throws BizNotFoundException {
		MemberVO member = memberDao.getMember(memId);
		if(member == null) throw new BizNotFoundException();
		return member;
	}

	// 모디파이
	@Override
	public void modifyMember(MemberVO member) throws BizNotEffectedException, BizNotFoundException {
		MemberVO vo = memberDao.getMember(member.getMemId());
		if(vo == null) throw new BizNotFoundException();
		int resultCnt = memberDao.updateMember(member);
		if(resultCnt == 0) throw new BizNotEffectedException();
	}

	// 딜리트
	@Override
	public void removeMember(MemberVO member) throws BizNotEffectedException, BizNotFoundException {
		MemberVO vo = memberDao.getMember(member.getMemId());
		if(vo == null) throw new BizNotFoundException();
		int resultCnt = memberDao.deleteMember(member);
		if(resultCnt == 0) throw new BizNotEffectedException();
		
	}

	// 레지스트
	@Override
	public void registMember(MemberVO member) throws BizNotEffectedException, BizDuplicateKeyException {
		MemberVO vo = memberDao.getMember(member.getMemId());
		if(vo != null) {
			throw new BizDuplicateKeyException();
		}
		if(vo == null) {
			int resultCnt = memberDao.insertMember(member);
			if(resultCnt == 0) throw new BizNotEffectedException();
		}
	}

}
