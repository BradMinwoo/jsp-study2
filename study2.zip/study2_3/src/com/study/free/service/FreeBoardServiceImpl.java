package com.study.free.service;

import java.util.List;

import com.study.exception.BizNotEffectedException;
import com.study.exception.BizNotFoundException;
import com.study.exception.BizPasswordNotMatchedException;
import com.study.free.dao.FreeBoardDaoOracle;
import com.study.free.dao.IFreeBoardDao;
import com.study.free.vo.FreeBoardSearchVO;
import com.study.free.vo.FreeBoardVO;

public class FreeBoardServiceImpl implements IFreeBoardService{
	IFreeBoardDao freeBoardDao = new FreeBoardDaoOracle();
	
	// 리스트
	@Override
	public List<FreeBoardVO> getBoardList(FreeBoardSearchVO searchVO) {
		// 밑의 메소드 실행전에 searchVO에 firstRow, lastRow이 세팅이 되면 되겠져
		int totalRowCount = freeBoardDao.getTotalRowCount(searchVO);
		searchVO.setTotalRowCount(totalRowCount);
		searchVO.pageSetting();
		List<FreeBoardVO> freeBoardList = freeBoardDao.getBoardList(searchVO); // List<FreeBoardVO>
		return freeBoardList;
	}

	// 뷰
	@Override
	public FreeBoardVO getBoard(int boNo) throws BizNotFoundException {
		FreeBoardVO freeBoard = freeBoardDao.getBoard(boNo);
		if(freeBoard == null) throw new BizNotFoundException();
		return freeBoard;
	}
	// 조회수
	@Override
	public void increaseHit(int boNo) throws BizNotEffectedException {
		int cnt = freeBoardDao.increaseHit(boNo);
		if(cnt == 0) throw new BizNotEffectedException();
	}

	// 모디파이
	@Override
	public void modifyBoard(FreeBoardVO freeBoard)
			throws BizNotFoundException, BizPasswordNotMatchedException, BizNotEffectedException {
		// 사용자가 글 등록했을 때의 비밀번호랑 지금 수정하려는 사람이 입력한 비밀번호가 같으면...
		// 같은 사람이구나로 인식해서 그 때만 수정 할 수 있게..
		FreeBoardVO vo = freeBoardDao.getBoard(freeBoard.getBoNo());
		
		// 글 등록했을 때의 비밀번호를                가지고 있는 객체 : vo
		// 지금 수정하려는 사람이 입력한 비밀번호를     가지고 있는 객체 : freeBoard
		if(vo == null) throw new BizNotFoundException();
		if(!vo.getBoPass().equals( freeBoard.getBoPass())) throw new BizPasswordNotMatchedException();
		int resultCnt = freeBoardDao.updateBoard(freeBoard);
		if(resultCnt == 0) throw new BizNotEffectedException();
		
	}
	
	// 딜리트
	@Override
	public void removeBoard(FreeBoardVO freeBoard)
			throws BizNotFoundException, BizPasswordNotMatchedException, BizNotEffectedException {
		// 비밀번호가 같으면 삭제, 아니면 삭제 못함
		FreeBoardVO vo = freeBoardDao.getBoard(freeBoard.getBoNo());
		if(vo == null) throw new BizNotFoundException();
		if(!vo.getBoPass().equals( freeBoard.getBoPass())) throw new BizPasswordNotMatchedException();
		int resultCnt = freeBoardDao.deleteBoard(freeBoard);
		if(resultCnt == 0) throw new BizNotEffectedException();
		
	}
	
	// 레지스트
	@Override
	public void registBoard(FreeBoardVO freeBoard) throws BizNotEffectedException {
		int resultCnt = freeBoardDao.insertBoard(freeBoard);
		if(resultCnt == 0) throw new BizNotEffectedException();
	}
	

}
