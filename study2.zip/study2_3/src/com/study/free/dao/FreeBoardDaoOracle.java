package com.study.free.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.study.exception.BizNotEffectedException;
import com.study.exception.DaoException;
import com.study.free.vo.FreeBoardSearchVO;
import com.study.free.vo.FreeBoardVO;

public class FreeBoardDaoOracle implements IFreeBoardDao{
	
	@Override
	public int getTotalRowCount(FreeBoardSearchVO searchVO) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = DriverManager.getConnection("jdbc:apache:commons:dbcp:study");
			StringBuffer sb = new StringBuffer();
			sb.append(" SELECT count(*)       ");
			sb.append(" FROM free_board       ");
			sb.append(" WHERE bo_del_yn = 'N' ");
			
			if(StringUtils.isNotEmpty(searchVO.getSearchWord())) {
				switch (searchVO.getSearchType()) {
				case "T":sb.append(" AND bo_title LIKE '%' || ? || '%'");break;
				case "W":sb.append(" AND bo_writer LIKE '%' || ? || '%'");break;
				case "C":sb.append(" AND bo_content LIKE '%' || ? || '%'");break;
				}
			}
			if(StringUtils.isNotEmpty(searchVO.getSearchCategory())) {
				sb.append(" AND bo_category = ?");
			}
			pstmt = conn.prepareStatement(sb.toString());
			int cnt = 1;
			if(StringUtils.isNotEmpty(searchVO.getSearchWord())) {
				pstmt.setString(cnt++, searchVO.getSearchWord());
			}
			if(StringUtils.isNotEmpty(searchVO.getSearchCategory())) {
				pstmt.setString(cnt++, searchVO.getSearchCategory());
			}
			rs = pstmt.executeQuery();
			if(rs.next()) {
				int resultCnt = rs.getInt(1);
				//int resultCnt = rs.getInt("count(*)");
				return resultCnt;
			}
			return 0;
		}catch(SQLException e) {
			throw new DaoException("getTotalRowCount : " + e.getMessage(),e);
		}finally {
			if(rs != null)  {try{rs.close();}  catch(Exception e){}}
			if(pstmt != null){try{pstmt.close();}catch(Exception e){}}
			if(conn != null){try{conn.close();}catch(Exception e){}}
		}
	}
	

	@Override
	public List<FreeBoardVO> getBoardList(FreeBoardSearchVO searchVO) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try{
			conn = DriverManager.getConnection("jdbc:apache:commons:dbcp:study");
			StringBuffer sb = new StringBuffer();
			sb.append(" SELECT * FROM       (                               ");
			sb.append(" SELECT a.*, rownum AS rnum  FROM (                  ");
			
			sb.append(" SELECT                                              ");
			sb.append("    to_char(bo_reg_date, 'YYYY-MM-DD') AS bo_reg_date");
			sb.append("   ,to_char(bo_mod_date, 'YYYY-MM-DD') AS bo_mod_date");
			sb.append("	 	, bo_no       , bo_title    , bo_category      ");
			sb.append("	 	, bo_writer   , bo_pass     , bo_content       ");
			sb.append("	 	, bo_ip       , bo_hit      , bo_del_yn        ");
			// code
			sb.append("      , b.comm_nm AS bo_category_nm                  ");
			sb.append(" FROM free_board a, comm_code b                      ");
			sb.append(" WHERE a.bo_category = b.comm_cd                     ");
			sb.append(" AND bo_del_yn = 'N'                                 ");
			
			if(StringUtils.isNotEmpty(searchVO.getSearchWord())) {
				switch (searchVO.getSearchType()) {
				case "T":sb.append(" AND bo_title LIKE '%' || ? || '%'");break;
				case "W":sb.append(" AND bo_writer LIKE '%' || ? || '%'");break;
				case "C":sb.append(" AND bo_content LIKE '%' || ? || '%'");break;
				}
			}
			if(StringUtils.isNotEmpty(searchVO.getSearchCategory())) {
				sb.append(" AND bo_category = ?");
			}
			
			sb.append(" ORDER BY bo_no DESC                                 ");
			
			sb.append(" ) a ) b                                             ");
			sb.append(" WHERE rnum BETWEEN ? and ?                          ");
			
			
			
			pstmt = conn.prepareStatement(sb.toString());
			
			int cnt = 1;
			
			if(StringUtils.isNotEmpty(searchVO.getSearchWord())) {
				pstmt.setString(cnt++, searchVO.getSearchWord());
			}
			if(StringUtils.isNotEmpty(searchVO.getSearchCategory())) {
				pstmt.setString(cnt++, searchVO.getSearchCategory());
			}
			
			pstmt.setInt(cnt++, searchVO.getFirstRow());
			pstmt.setInt(cnt++, searchVO.getLastRow());
			
			rs = pstmt.executeQuery();
			
			List<FreeBoardVO> freeBoardList = new ArrayList<>();
			while(rs.next()){
				FreeBoardVO freeBoard = new FreeBoardVO();
				freeBoard.setBoNo(rs.getInt("bo_no"));
				freeBoard.setBoTitle(rs.getString("bo_title"));
				freeBoard.setBoCategory(rs.getString("bo_category"));
				freeBoard.setBoWriter(rs.getString("bo_writer"));
				freeBoard.setBoPass(rs.getString("bo_pass"));
				freeBoard.setBoContent(rs.getString("bo_content"));
				freeBoard.setBoIp(rs.getString("bo_ip"));
				freeBoard.setBoHit(rs.getInt("bo_hit"));
				freeBoard.setBoRegDate(rs.getString("bo_reg_date"));
				freeBoard.setBoModDate(rs.getString("bo_mod_date"));
				freeBoard.setBoDelYn(rs.getString("bo_del_yn"));
				freeBoard.setBoCategoryNm(rs.getString("bo_category_nm"));
				freeBoardList.add(freeBoard);
			}
			return freeBoardList;
			
		}catch(SQLException e){
			throw new DaoException("getBoardList : "+e.getMessage(),e);
		}finally{
			if(rs != null)  {try{rs.close();}  catch(Exception e){}}
			if(pstmt != null){try{pstmt.close();}catch(Exception e){}}
			if(conn != null){try{conn.close();}catch(Exception e){}}
		}
	}

	@Override
	public FreeBoardVO getBoard(int boNo) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try{
			conn = DriverManager.getConnection("jdbc:apache:commons:dbcp:study");
			StringBuffer sb = new StringBuffer();
			sb.append(" SELECT                                              ");
			sb.append("    to_char(bo_reg_date, 'YYYY-MM-DD') AS bo_reg_date");
			sb.append("   ,to_char(bo_mod_date, 'YYYY-MM-DD') AS bo_mod_date");
			sb.append("	 	, bo_no       , bo_title    , bo_category      ");
			sb.append("	 	, bo_writer   , bo_pass     , bo_content       ");
			sb.append("	 	, bo_ip       , bo_hit      , bo_del_yn        ");
			//code
			sb.append("      , b.comm_nm AS bo_category_nm                  ");
			sb.append(" FROM free_board a, comm_code b                      ");
			sb.append(" WHERE a.bo_category = b.comm_cd                     ");
			sb.append(" AND bo_no = ?                                       ");
			sb.append(" AND bo_del_yn = 'N'                                 ");
			
			pstmt = conn.prepareStatement(sb.toString());
			pstmt.setInt(1, boNo);
			rs = pstmt.executeQuery();
			
			if(rs.next()){
				FreeBoardVO freeBoard = new FreeBoardVO();
				freeBoard.setBoNo(rs.getInt("bo_no"));
				freeBoard.setBoTitle(rs.getString("bo_title"));
				freeBoard.setBoCategory(rs.getString("bo_category"));
				freeBoard.setBoWriter(rs.getString("bo_writer"));
				freeBoard.setBoPass(rs.getString("bo_pass"));
				freeBoard.setBoContent(rs.getString("bo_content"));
				freeBoard.setBoIp(rs.getString("bo_ip"));
				freeBoard.setBoHit(rs.getInt("bo_hit"));
				freeBoard.setBoRegDate(rs.getString("bo_reg_date"));
				freeBoard.setBoModDate(rs.getString("bo_mod_date"));
				freeBoard.setBoDelYn(rs.getString("bo_del_yn"));
				freeBoard.setBoCategoryNm(rs.getString("bo_category_nm"));
				return freeBoard;
			}
			return null;
		}catch(SQLException e){
			throw new DaoException("getBoard :"+e.getMessage(),e);
		}finally{
			if(rs != null)  {try{rs.close();}  catch(Exception e){}}
			if(pstmt != null){try{pstmt.close();}catch(Exception e){}}
			if(conn != null){try{conn.close();}catch(Exception e){}}
		}	
	}

	@Override
	public int increaseHit(int boNo) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DriverManager.getConnection("jdbc:apache:commons:dbcp:study");
			StringBuffer sb = new StringBuffer();
			sb.append(" UPDATE free_board SET  ");
			sb.append(" bo_hit = bo_hit+1      ");
			sb.append(" WHERE bo_no = ?        ");
			pstmt=conn.prepareStatement(sb.toString());
			pstmt.setInt(1, boNo);
			int resultCnt = pstmt.executeUpdate();
			return resultCnt;
		}catch(SQLException e) {
			throw new DaoException("increaseHit : " + e.getMessage(),e);
		}finally {
			if(pstmt != null){try{pstmt.close();}catch(Exception e){}}
			if(conn != null){try{conn.close();}catch(Exception e){}}
		}
	}

	@Override
	public int updateBoard(FreeBoardVO freeBoard) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		// ResultSet은 필요없어요
		try{
			conn = DriverManager.getConnection("jdbc:apache:commons:dbcp:study");
			StringBuffer sb = new StringBuffer();
			sb.append(" UPDATE free_board SET            ");
			sb.append("      bo_title      = ?           ");
			sb.append("    , bo_category   = ?           ");
			sb.append("    , bo_content    = ?           ");
			sb.append("    , bo_ip         = ?           ");
			sb.append("    , bo_hit        = bo_hit+1    ");
			sb.append("    , bo_mod_date   = sysdate     ");
			sb.append(" WHERE bo_no         = ?          ");
			pstmt = conn.prepareStatement(sb.toString());		
			int cnt = 1;
			pstmt.setString(cnt++, freeBoard.getBoTitle());
			pstmt.setString(cnt++, freeBoard.getBoCategory());
			pstmt.setString(cnt++, freeBoard.getBoContent());
			pstmt.setString(cnt++, freeBoard.getBoIp());
			pstmt.setInt(cnt++, freeBoard.getBoNo());
			int resultCnt = pstmt.executeUpdate();
			return resultCnt;
			
		}catch(SQLException e){
			throw new DaoException("updateBoard : " + e.getMessage(),e);		
		}finally{
			if(pstmt != null){try{pstmt.close();}catch(Exception e){}}
			if(conn != null){try{conn.close();}catch(Exception e){}}
		}
	}

	@Override
	public int deleteBoard(FreeBoardVO freeBoard) {
		// edit에서 사용자가 수정한거 DB에서 수정되도록
		Connection conn = null;
		PreparedStatement pstmt = null;
		// ResultSet은 필요없어요
		try{
			conn = DriverManager.getConnection("jdbc:apache:commons:dbcp:study");
			StringBuffer sb = new StringBuffer();
			sb.append(" UPDATE free_board SET            ");
			sb.append(" bo_del_yn = 'Y'                  ");
			sb.append(" WHERE bo_no         = ?          ");
			pstmt = conn.prepareStatement(sb.toString());		
			pstmt.setInt(1, freeBoard.getBoNo());
			int resultCnt = pstmt.executeUpdate();
			return resultCnt;
		}catch(SQLException e){
			throw new DaoException("delete : " + e.getMessage(),e);
		}finally{
			if(pstmt != null){try{pstmt.close();}catch(Exception e){}}
			if(conn != null){try{conn.close();}catch(Exception e){}}
		}
	}

	@Override
	public int insertBoard(FreeBoardVO freeBoard) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try{
			conn = DriverManager.getConnection("jdbc:apache:commons:dbcp:study");
			StringBuffer sb = new StringBuffer();
			sb.append(" INSERT INTO free_board (                        ");
			sb.append("      bo_no       , bo_title        , bo_category");
			sb.append("    , bo_writer   , bo_pass         , bo_content ");
			sb.append("    , bo_ip       , bo_hit          , bo_reg_date");
			sb.append("    , bo_mod_date , bo_del_yn                    ");
			sb.append(" ) VALUES (                                      ");
			sb.append("     SEQ_FREE_BOARD.nextval   , ?   , ?          ");
			sb.append("   , ?            , ?               , ?          ");
			sb.append("   , ?            , 0               , sysdate    ");
			sb.append("   , null         , 'N'                          ");
			sb.append(" )                                               ");
			pstmt = conn.prepareStatement(sb.toString());
			int cnt = 1;
			pstmt.setString(cnt++, freeBoard.getBoTitle());
			pstmt.setString(cnt++, freeBoard.getBoCategory());
			pstmt.setString(cnt++, freeBoard.getBoWriter());
			pstmt.setString(cnt++, freeBoard.getBoPass());
			pstmt.setString(cnt++, freeBoard.getBoContent());
			pstmt.setString(cnt++, freeBoard.getBoIp());
			int resultCnt = pstmt.executeUpdate();
			return resultCnt;
			
		}catch(SQLException e){
			throw new DaoException("regist : " + e.getMessage(),e);		
		}finally{
			if(pstmt != null){try{pstmt.close();}catch(Exception e){}}
			if(conn != null){try{conn.close();}catch(Exception e){}}
		}
	}


	
}
