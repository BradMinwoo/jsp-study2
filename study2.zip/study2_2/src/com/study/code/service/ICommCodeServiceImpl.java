package com.study.code.service;

import java.util.List;

import com.study.code.dao.CommCodeDaoOracle;
import com.study.code.dao.ICommCodeDao;
import com.study.code.vo.CodeVO;

public class ICommCodeServiceImpl implements ICommCodeService {

	@Override
	public List<CodeVO> getCodeListByParent(String parentCode) {
		// TODO Auto-generated method stub
		ICommCodeDao codeDao = new CommCodeDaoOracle();
		return codeDao.getCodeListByParent(parentCode);
	}
	

}
